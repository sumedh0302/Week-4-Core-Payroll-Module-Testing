import pandas as pd
from dateutil.parser import parse

print("\nPayroll Validation Started...\n")

employee_df = pd.read_csv("zenvy_employees.csv")
payroll_df = pd.read_csv("zenvy_payroll.csv")
attendance_df = pd.read_csv("zenvy_attendance.csv")

merged_df = employee_df.merge(payroll_df, on="employee_id", how="left")
merged_df = merged_df.merge(attendance_df, on="employee_id", how="left")

def validate_payroll(row):

    emp_id = row['employee_id']

    if pd.isna(row['gross_salary']):
        print(f" Payroll Record Missing for Employee {emp_id}")
        return

    try:
        gross_salary = float(row['gross_salary'])
        tax = float(row['tax_deduction'])
        pf = float(row['pf_deduction'])
        net_salary = float(row['net_salary'])
        base_salary = float(row['base_salary'])
        working_days = int(row['working_days'])
        present_days = int(row['present_days'])
        overtime_hours = float(row['overtime_hours'])


        try:
            parse(str(row['joining_date']), dayfirst=True)
        except:
            print(f" Invalid Joining Date for Employee {emp_id}")

        expected_tax = gross_salary * 0.10
        if abs(expected_tax - tax) > 1:
            print(f" Tax Error for Employee {emp_id}")

        expected_pf = gross_salary * 0.05
        if abs(expected_pf - pf) > 1:
            print(f" PF Error for Employee {emp_id}")

        if overtime_hours < 0:
            print(f" Negative OT Hours for Employee {emp_id}")

        hourly_rate = gross_salary / (22 * 8)
        ot_pay = hourly_rate * overtime_hours * 2

        bonus = 0
        if present_days >= 21:
            bonus = base_salary * 0.05

        expected_gross = base_salary + ot_pay + bonus
        if abs(expected_gross - gross_salary) > 100:
            print(f" Gross Salary Mismatch for Employee {emp_id}")

        if present_days > working_days:
            print(f" Attendance Error for Employee {emp_id}")

       
        calculated_net = gross_salary - tax - pf
        if abs(calculated_net - net_salary) > 1:
            print(f" Net Salary Error for Employee {emp_id}")

        if net_salary < 0:
            print(f" Invalid Net Salary for Employee {emp_id}")

    except:
        print(f" Data Format Error for Employee {emp_id}")

merged_df.apply(validate_payroll, axis=1)

print("\nPayroll Validation Completed!\n")